package com.example.authapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnLogin.setOnClickListener {
            // get the email and password from the EditText
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            // get access to an instance of FirebaseAuth
            FirebaseAuth.getInstance().
                    signInWithEmailAndPassword(email, password)
                    .addOnSuccessfulListener {
                        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT)
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Login Unsuccessful", Toast.LENGTH_SHORT)
                        it.printStackTrace()
                    }
                    .addOnCanceledListener {

                    }
        }

        btnSignUp.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            // get access to an instance of FirebaseAuth
            FirebaseAuth.getInstance()
            createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Sign up Successful", Toast.LENGTH_SHORT)
                    }.addOnFailureListener {
                        Toast.makeText(this, "Sign up Unsuccessful", Toast.LENGTH_SHORT)
                        it.printStackTrace()
                    }.addOnCanceledListener{

                    }
        }

        FirebaseAuth.getInstance().currentUser?.let { currentUser ->
            // the user is already logged in, so get hte details from them
            // this is the information you can use to update the profile in the app, you can add registration data

            val uid: String = currentUser.uid
            val name: String? = currentUser.displayName
            val email = String? = currentUser.email
            val contactNumber = currentUser.phoneNumber
        } ?: kotlin.run {
            // currentUser is null, user not logged in, sign in again
        }
    }

    fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }
}